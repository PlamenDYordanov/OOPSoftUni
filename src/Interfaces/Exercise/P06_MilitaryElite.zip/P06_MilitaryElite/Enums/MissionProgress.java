package Interfaces.Exercise.P06_MilitaryElite.Enums;

public enum MissionProgress {
    inProgress,
    finished

}

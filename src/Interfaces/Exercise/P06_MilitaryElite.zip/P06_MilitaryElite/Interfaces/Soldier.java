package Interfaces.Exercise.P06_MilitaryElite.Interfaces;

public interface Soldier {
    String getFirstName();
    String getLastName();
    int getId();
}

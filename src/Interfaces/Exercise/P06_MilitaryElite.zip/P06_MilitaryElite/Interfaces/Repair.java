package Interfaces.Exercise.P06_MilitaryElite.Interfaces;

public interface Repair {
    String getPartName();
    int getHours();
}

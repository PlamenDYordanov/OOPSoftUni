package P02_Shapes;

public class Circle extends  Shape{
    private Double radius;

    public Circle(Double radius) {

        this.radius = radius;
    }

    @Override
    public void calculatePerimeter() {
        super.perimeter = 2 * Math.PI * getRadius();
    }

    @Override
    public void calculateArea() {
        super.area = Math.PI * Math.pow(getRadius(),2);

    }

    public Double getRadius() {
        return radius;
    }
}

package P02_Shapes;

public abstract class Shape {
    protected Double perimeter;
    protected Double area;



    public abstract  void calculatePerimeter();
    public abstract  void calculateArea();

}

package Interfaces.Exercise.P06_MilitaryElite.Enums;

public enum Corps {
    Airforces,
    Marines
}

package Interfaces.Exercise.P06_MilitaryElite.Interfaces;

import Interfaces.Exercise.P06_MilitaryElite.entity.PrivateImpl;

public interface Lieutenant {
    void addPrivate(PrivateImpl priv);
}

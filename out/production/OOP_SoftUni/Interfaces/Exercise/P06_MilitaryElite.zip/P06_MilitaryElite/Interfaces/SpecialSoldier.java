package Interfaces.Exercise.P06_MilitaryElite.Interfaces;

public interface SpecialSoldier {
    String getCorps();

}

package Interfaces.Exercise.P06_MilitaryElite.Interfaces;

public interface Mission {
    String getName();
    String getState();
    void completeMission();
}

package fairyShop.common;

public enum Command {
    AddHelper,
    AddPresent,
    AddInstrumentToHelper,
    CraftPresent,
    Report,
    Exit,
}

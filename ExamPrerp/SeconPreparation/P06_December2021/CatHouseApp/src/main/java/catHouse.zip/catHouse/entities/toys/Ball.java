package catHouse.entities.toys;

public class Ball extends  BaseToy {
    private static final double DEFAULT_PRICE = 10;
    private static final int DEFAULT_SOFTNESS = 1;
    public Ball() {
        super(DEFAULT_SOFTNESS, DEFAULT_PRICE);
    }

}

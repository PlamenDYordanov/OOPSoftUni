package fairyShop.models;

public class Happy extends BaseHelper{
    private static final int DEFAULT_ENERGY = 100;
    public Happy(String name) {
        super(name, DEFAULT_ENERGY);
    }
}

package catHouse.entities.toys;

public class Mouse extends BaseToy{
    private static final int DEFAULT_SOFTNESS = 5;
    private static final double DEFAULT_PRICE = 15;

    public Mouse() {
        super(DEFAULT_SOFTNESS, DEFAULT_PRICE);
    }
}
